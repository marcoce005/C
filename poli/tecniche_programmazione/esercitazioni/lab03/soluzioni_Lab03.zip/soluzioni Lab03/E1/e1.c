#include<stdlib.h>
#include<string.h>
#include<stdio.h>

#define MAXLEN 100

int main(void) {

  FILE *in = NULL;
  int temp, n1=0, n2=0;
  char num_sensore;
  float media1=0.0, media2=0.0;
  char filename[MAXLEN];

  printf("Inserire nome del file: ");
  scanf("%s", filename);
  in = fopen(filename, "r");
  if (in == NULL) {
    printf("errore aprendo il file %s\n", filename);
    return EXIT_FAILURE;
  }
  
  while (fscanf(in, " T%c:", &num_sensore)!=EOF) {
    printf("ho letto: T%c\n", num_sensore); // aggiunta per verificare il corretto input
    while (fscanf(in, "%d", &temp)==1) {
      printf("  ho letto: %d\n", temp); // aggiunta per verificare il corretto input
      if (num_sensore=='1') {
        n1++; media1+=temp;
      } else {
        n2++; media2+=temp;
      }
    }
    fscanf(in, " ,"); // fa passare la virgola se c'e' (precedutra da eventuali spazi)
  }
  media1 /= n1;
  media2 /= n2;
  printf("T1: %d temperature lette - media: %.1f\n", n1, media1);
  printf("T2: %d temperature lette - media: %.1f\n", n2, media2);
  
  return EXIT_SUCCESS;
}

