#include<stdlib.h>
#include<string.h>
#include<stdio.h>

#define MAXLEN 100

void sommaTempi(int T1[3], int T2[3]);
void dividiTempo(int T[3], int n);

int main(void) {
  FILE *in = NULL;
  int Media[3]={0,0,0}, T[3];
  int n=0;
  char filename[MAXLEN];

  printf("Inserire nome del file: ");
  scanf("%s", filename);
  in = fopen(filename, "r");
  if (in == NULL) {
    printf("errore aprendo il file %s\n", filename);
    return EXIT_FAILURE;
  }
  
  while (fscanf(in, "%d:%d:%d", &T[0], &T[1], &T[2])!=EOF) {
    printf("ho letto: %02d:%02d:%02d\n", T[0], T[1], T[2]); // stampa per verifica 
    sommaTempi(Media,T);
    n++;
  }
  dividiTempo(Media,n);
  
  printf("ho letto %d tempi. La media è %02d:%02d:%02d\n",
         n, Media[0], Media[1], Media[2]); 

  return EXIT_SUCCESS;
}

void sommaTempi(int T1[3], int T2[3]) {
  int somma;

  // secondi
  somma = T1[2]+T2[2];
  T1[2] = somma%60;
  // minuti (contando il riporto dai secondi)
  somma = T1[1]+T2[1]+somma/60;
  T1[1] = somma%60;
  // ore (contando il riporto dai secondi)
  T1[0] = T1[0]+T2[0]+somma/60;    
}

void dividiTempo(int T[3], int n) {
  int secondi = T[2] + 60*(T[1]+60*T[0]);
  secondi /= n; // dividi
  T[2] = secondi%60;
  int minuti = secondi / 60;
  T[1] = minuti%60;
  T[0] = minuti/60;
}

