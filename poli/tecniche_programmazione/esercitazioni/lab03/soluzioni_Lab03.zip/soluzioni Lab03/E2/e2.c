#include<stdlib.h>
#include<string.h>
#include<stdio.h>

void calcola_e_stampa_approssimato(int g1, int m1, int a1, int n);
void calcola_e_stampa(int g1, int m1, int a1, int n);

int main(void) {
  int n;
  int g, m, a;
  printf("scrivi una data (formato gg/mm/aaaa): ");
  scanf ("%d/%d/%d", &g,&m,&a);
  printf("ho letto: %02d/%02d/%04d\n", g,m,a); // aggiunta per verificare il corretto input
  printf("scrivi N (numero di giorni dopo la data): ");
  scanf ("%d", &n);
  printf("ho letto: %d\n", n); // aggiunta per verificare il corretto input

  calcola_e_stampa_approssimato(g,m,a,n);
  calcola_e_stampa(g,m,a,n);
  
  return EXIT_SUCCESS;
}

int bisestile(int a) {
  return a%4==0 && (a%400==0 || a%100!=0);
}

int conta_bisestili(int n_g) {
  // conta bisestili completamente inclusi nei giorni
  int n_b = (n_g/(400*365+97))*97; // comincia con gruppi di 400 anni;
  n_g = (n_g%(400*365+97));
  n_b += (n_g/(100*365+24))*24; // gruppi residui di 100;
  n_g = (n_g%(100*365+24));
  n_b += n_g/(4*365+1);
  return n_b;
}

int giorni_del_mese(int m, int a) {
  switch(m) {
  case 2:
    if (bisestile(a)) return 29;
    else return 28;
  case 4: case 6: case 9: case 11:
    return 30;
    break;
  default:
    return 31;
  }
}

void calcola_e_stampa_approssimato(int g, int m, int a, int n) {
  // aggiorna anno
  int gm;
  int n_bisestili = conta_bisestili(n);
  int incr_anni = (n-n_bisestili)/365;
  n = (n-n_bisestili)%365;
  a += incr_anni;

  // aggiorna mese e giorno
  g+=n;
  
  while(g>(gm=giorni_del_mese(m,a))) {
    g -= gm; // gm usato per non chiamare due volte la funzione
    m++;
    if (m==13) {
      m=1;
      a++;
    }
  }
    
  printf("la data finale e': %02d/%02d/%04d\n", g,m,a);
}

int data_a_giorni(int g, int m, int a) {
  int n;
  // escludi l'anno in corso;
  n = (a-1)*365 + (a-1)/4 - (a-1)/100 + (a-1)/400;
  for (int i=1; i<m; i++)
    n += giorni_del_mese(i,a);
  n+=g;
  return n;
}

void calcola_e_stampa(int g, int m, int a, int n) {
  // aggiorna anno
  int giorni_da_inizio = data_a_giorni(g,m,a);
  printf("giorni da inizio: %d\n",giorni_da_inizio);
  calcola_e_stampa_approssimato(0, 1, 1, n+giorni_da_inizio);  
}
